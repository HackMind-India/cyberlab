# HackMind India — Ready Package

## Included
- `index.html` — upgraded portal with Practice Tests + UPSC Foundation Classes
- `data/questions.json` — repaired valid JSON from the supplied repository
- `data/syllabus.json` — original syllabus file
- `data/resources.json` — UPSC Foundation Batch 2025 (Hindi Medium) resources, with video/PDF links

## Important
The supplied `questions.json` was truncated/incomplete at question 160. The final incomplete record was removed so the JSON is valid; the 159 complete questions were preserved. No new questions were fabricated.

## Deploy
Upload/replace the files in the GitHub repository so that the structure remains:
```
index.html
data/
  questions.json
  syllabus.json
  resources.json
```
Render will redeploy from the connected GitHub repository.
